# AppNana
AppNana Cheat.  

Menggunakan metode GOYONG(Gotong Royong), dimana semua device yang menggunakan script ini akan bekerja sama untuk mencari point. Misalkan user A sudah login di script ini, maka data nya akan terdaftar di server pusat kita, lalu ketika menjalan kan scriptnya, kita akan mencarikan point juga untuk semua yang terdaftar di server. Hal ini bertujuan agar IP tidak akan di block karena kita menggunakan banyak IP.

Dilarang untuk menulis ulang/mengedit code yang sudah dibuat. Karena bisa menyebabkan akun tersuspend.
