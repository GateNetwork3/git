# cashtree-bot
Bot cashtree auto earning

# install
1. git clone https://github.com/ccocot/cashtree-bot.git
2. cd cashtree-bot
3. npm install
4. node index.js

# another repository
https://github.com/radenvodka/cashtree
