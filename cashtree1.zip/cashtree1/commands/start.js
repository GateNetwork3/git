'use strict'

const { Command } = require('@adonisjs/ace')
const CashTree = require('../src/cashtree')

class Start extends Command {
  static get signature () {
    return `
      start
      { --mmses=@value : msess option }
      { --av=@value : av option }
      { --gaid=@value : gaid option }
      { --imei=@value : imei option }
    `
  }

  static get description () {
    return 'Run the cashtree bot'
  }

  async handle (args, flags) {
    if (!flags.mmses) {
      flags.mmses = '4RWIaxbKGxgGlV78wVCrEsdO9Xr9GB59BdfWHZfev4sbJNRQNWN5z9lDG0qN1H1Wbz+QxxeeRmCMvjovGAPugg=='
    }

    if (!flags.av) {
      flags.av = '23000'
    }

    if (!flags.gaid) {
      flags.gaid = '47738310-d16e-4450-8845-279de8234a95'
    }

    if (!flags.imei) {
      flags.imei = '869123020685533'
    }

    const newCash = new CashTree(flags)
    newCash.on('data', async (data) => {
      const header = `[${data.a}] ${data.tt} (${data.tp} - Reward: ${data.lr})`
      try {
        const start = await newCash.adStart(data.a)
        await newCash.adR(start.result.redirect)
        if (data.tp === 'install') await newCash.usersAppsAdd(data.ut, data.pk)
        const reward = await newCash.adCompleteReward(data.a)
        if (reward.code !== 0) throw new Error(reward.msg)
        console.log(`${header} | Total: ${reward.result.cash_status.total} - Earned: ${reward.result.cash_status.earn_today}`)
      } catch (err) {
        console.log(`${header} | Error: ${err.message}`)
      }
    })
    newCash.getAds()
  }
}

module.exports = Start
